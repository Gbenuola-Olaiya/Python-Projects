Project Description
Soccer Shark is a tool that would enable soccer coaches to explain and visualize their game-plans to their players during training sessions. 
This tool would be able to also generate possible counter formations that opponents may use based on flaws in the coach’s formation.

To run the project, open the TP3 file and run in VSCode preferrably. I used no modules that need to be installed.

ShortCuts.
If ‘r’ is pressed, everything resets
If ‘b’ is pressed during the buildUp Phase, everything in the buildUp phase resets
If ‘f’ is pressed during the final third phase, everything resets in the final third phase.
