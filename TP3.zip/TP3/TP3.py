import basic_graphics
import tkinter as tk  
from cmu_112_graphics import *
import os
import string
import math


class SplashScreenMode(Mode):
    def appStarted(mode):
        mode.rectLength = 200
        mode.rectWidth = 100
        mode.loginX1 = mode.width/2 - mode.rectLength/2
        mode.loginY1 = mode.height/3 - 100
        mode.loginX2 = mode.width/2 + mode.rectLength/2 
        mode.loginY2 = (mode.height/3 + mode.rectWidth) - 150
        mode.createAcctX1 = mode.loginX1
        mode.createAcctY1 = mode.height/3
        mode.createAcctX2 = mode.loginX2
        mode.createAcctY2 = (mode.height/ 3 + mode.rectWidth) - 50
        mode.image = mode.loadImage('SplashPageA.png')
        mode.firstName = None

    def distance(mode, x1, y1, x2, y2):
        return ((x1-x2)**2 + (y1-y2)**2)**0.5 

    def userNameMatchesPassword(mode, userName, password, path):
        if f'{userName}.txt' in path:
            fle = open(f'{path}', 'r')
            if fle.mode == 'r':
                contents = fle.read().splitlines()
                if userName == contents[2].split(':')[1].strip() and (
                    password == contents[3].split(':')[1].strip()):
                        return True
                else: return False
        else:
            return False

    def mousePressed(mode, event):
        if (event.x >= mode.loginX1 and event.x <= mode.loginX2) and (
            event.y >= mode.loginY1 and event.y <= mode.loginY2):
                userName = mode.getUserInput('Username:')
                password = mode.getUserInput('Password:')
                if len(userName) != 0 and len(password) != 0:
                    if mode.userNameMatchesPassword(userName, password,f'{userName}.txt'):
                        mode.app.setActiveMode(mode.app.createMode)
                    else: mode.app.showMessage('Invalid Username or Password!!')
                else:
                    mode.app.showMessage('Invalid Username or Password!!')


        elif (event.x >= mode.createAcctX1 and event.x <= mode.createAcctX2) and (
            event.y >= mode.createAcctY1 and event.y <= mode.createAcctY2):
                mode.firstName = mode.getUserInput('First Name:')
                LastName = mode.getUserInput('Last Name: ')
                mode.userName = mode.getUserInput('Username:')
                password = mode.getUserInput('Password (At least 8 Characters):')
                nFile = open(f'{mode.userName}.txt', 'a+')
                if (userName != None) and (password != None and len(password) >= 8):
                    mode.message = f'Hi {mode.firstName}'
                    nFile.write(f'FirstName: {mode.firstName}\n')
                    nFile.write(f'LastName: {LastName}\n')
                    nFile.write(f'UserName: {userName}\n')
                    nFile.write(f'Password: {password}\n')
                    mode.app.setActiveMode(mode.app.createMode)
                else:
                    mode.app.showMessage('Invalid Username or Password!!')

    def redrawAll(mode, canvas):
        canvas.create_image(mode.width/2, mode.height/2, image=ImageTk.PhotoImage(mode.image))
        canvas.create_text(mode.width/2, 20, text='Welcome to Soccer Shark!', 
                            fill='black', font='Arial 25 bold')

        canvas.create_rectangle(mode.loginX1, mode.loginY1, mode.loginX2, 
                                            mode.loginY2, fill='light grey')
        canvas.create_text(mode.loginX1 + mode.rectLength/2, 
            mode.loginY1 + (mode.rectWidth - 50)/2, text='Login', 
            font='Magic 16 bold')

        canvas.create_rectangle(mode.createAcctX1, mode.createAcctY1, 
            mode.createAcctX2, mode.createAcctY2, fill='light grey')

        canvas.create_text(mode.createAcctX1 + mode.rectLength/2, 
            mode.createAcctY1 + (mode.rectWidth - 50)/2,
            text='Create An Account', font='Magic 16 bold')

class CreateMode(Mode):
    def appStarted(mode):
        mode.rectLength = 200
        mode.rectWidth = 100
        mode.four231X1 = mode.width/2 - mode.rectLength/2
        mode.four231Y1 = mode.height / 3 - 100
        mode.four231X2 = mode.width/2 + mode.rectLength/2
        mode.four231Y2 = (mode.height/3 + mode.rectWidth) - 100
        mode.four33X1 = mode.four231X1
        mode.four33Y1 = mode.height/3 + 50
        mode.four33X2 = mode.four231X2
        mode.four33Y2 = (mode.height/3 + mode.rectWidth) + 50
        mode.createMineX1 = mode.four231X1
        mode.createMineY1 = mode.four33Y1 + 150
        mode.createMineX2 = mode.four231X2
        mode.createMineY2 = mode.four33Y2 + 150
        mode.image = mode.loadImage('SelectP.jpg')

    def drawWelcomeCreateMode(mode, canvas):
        canvas.create_line(10, mode.height-30, 60, mode.height-30, 
        fill='blue', arrow='first', width=35)

        canvas.create_text(35, (2*mode.height-60)/2, text='BACK', 
                                                    font='Arial 10 bold')

        canvas.create_text(mode.width/2, 38, 
        text='Please Select a Formation Below Or Click on Create Mine',
        fill='orange', font='Arial 25 bold')

    def draw4231Select(mode, canvas):
        canvas.create_rectangle(mode.four231X1, mode.four231Y1, mode.four231X2, 
                                                mode.four231Y2, fill='yellow')

        canvas.create_text(mode.four231X1 + mode.rectLength/2, 
            mode.four231Y1 + mode.rectWidth/2, text='4-2-3-1', 
            font='Magic 25 bold')

    def draw433Select(mode, canvas):
        canvas.create_rectangle(mode.four33X1, mode.four33Y1, mode.four33X2, 
                                            mode.four33Y2, fill='orange')

        canvas.create_text(mode.four33X1 + mode.rectLength/2, 
        mode.four33Y1 + mode.rectWidth/2, text='4-3-3', 
        font='Magic 25 bold')

    def drawCreateMineSelect(mode, canvas):
        canvas.create_rectangle(mode.createMineX1, mode.createMineY1, 
        mode.createMineX2, mode.createMineY2, fill='yellow')

        canvas.create_text(mode.createMineX1 + mode.rectLength/2, 
        mode.createMineY1 + mode.rectWidth//2, text='Create Mine!', 
        font='Magic 25 bold')

    def drawCreateModeFormationSelect(mode, canvas):
        mode.draw4231Select(canvas)
        mode.draw433Select(canvas)
        mode.drawCreateMineSelect(canvas)

    def mousePressed(mode, event):
        if (event.x >= mode.four231X1 and event.x <= mode.four231X2) and (
            event.y >= mode.four231Y1 and event.y <= mode.four231Y2):
                mode.app.setActiveMode(mode.app.create4231)
                # fle = open(f'{mode.userName}.txt', 'a+')
                # fle.write('Formation Last Used: 4-2-3-1')

        elif (event.x >= mode.four33X1 and event.x <= mode.four33X2) and (
            event.y >= mode.four33Y1 and event.y <= mode.four33Y2):
                mode.app.setActiveMode(mode.app.create433)
                # fle = open(f'{mode.userName}.txt', 'a+')
                # fle.write('Formation Last Used: 4-3-3')

        elif (event.x >= mode.createMineX1 and event.x <= mode.createMineX2) and (
            event.y >= mode.createMineY1 and event.y <= mode.createMineY2):
                mode.app.setActiveMode(mode.app.CreateMine)

        elif (event.x >= 10 and event.x <= 60) and (event.y >= mode.height-50 and
            event.y <= mode.height):
                mode.app.setActiveMode(mode.app.splashScreenMode)

    def redrawAll(mode, canvas):
        canvas.create_image(mode.width/2, mode.height/2, image=ImageTk.PhotoImage(mode.image))
        mode.drawWelcomeCreateMode(canvas)
        mode.drawCreateModeFormationSelect(canvas)

class Four231Mode(Mode):
    def appStarted(mode):
        mode.centerCircleCx = 665
        mode.centerCircleCy = 330
        mode.centerCircleR = 100
        mode.kickOffDotR = 6
        mode.box18X1 = 165
        mode.box18RX1 = 1040
        mode.box18Y1 = 140
        mode.box18X2 = 290
        mode.box18RX2 = 1165
        mode.box18Y2 = 540
        mode.box6X1 = mode.box18X1
        mode.box6X2 = mode.box6X1 + 125/3
        mode.box6RX1 = mode.box6X1 + (1000 - (mode.box6X2 - mode.box6X1))
        mode.box6Y1 = mode.box18Y1 + 120
        mode.box6RX2 = mode.box6RX1 + (mode.box6X2 - mode.box6X1) 
        mode.box6Y2 = mode.box6Y1 + 400/3
        mode.penaltyX = mode.box18X1 + (2/3)*125
        mode.penaltyRX = mode.box18RX1 + (1/3)*125 
        mode.penaltyY = mode.box6Y1 + 0.5*(mode.box6Y2 - mode.box6Y1)
        mode.penaltyR = 5
        mode.goalPostX1 = 165 - (mode.box6X2 - mode.box6X1)/3
        mode.goalPostX2 = mode.box6X1
        mode.goalPostRX1 = mode.goalPostX2 + 1000
        mode.goalPostY1 = mode.box6Y1 + 15
        mode.goalPostRX2 = mode.goalPostRX1 + (mode.goalPostX2 - mode.goalPostX1)
        mode.goalPostY2 = mode.box6Y2 - 15
        mode.penaltyArcX1 = mode.box18X2 - 30
        mode.rPenaltyArcX1 = mode.box18RX1 - 30
        mode.penaltyArcY1 = mode.box18Y1 + (mode.box6Y1-mode.box18Y1) + 10
        mode.rPenaltyArcY1 = mode.penaltyArcY1
        mode.penaltyArcX2 = mode.box18X2 + 30
        mode.rPenaltyArcX2 = mode.box18RX1 + 30
        mode.penaltyArcY2 = mode.box18Y2 - (mode.box18Y2 - mode.box6Y2) - 10
        mode.rPenaltyArcY2 = mode.penaltyArcY2
        mode.players = [[182, 322, 1, False, (), (), False], [332, 549, 2, False, (), (), False], 
        [296, 390, 6, False, (), (), False], [293,258,5, False, (), (), False],[331, 124, 3, False, (), (), False], 
        [395, 407, 4, False, (), (), False], [395, 241, 8, False, (), (), False], [498, 176, 11, False, (), (), False],
        [498,322,10, False, (), (), False], [498, 469, 7, False, (), (), False],[603,322, 9, False, (), (), False]]
        mode.buttonCy = 35
        mode.buildUpCx = 278
        mode.finalThirdCx = 880
        mode.movePlayer = False
        mode.buildUpX1 = 254
        mode.buttonY1 = 22
        mode.buildUpX2 = 350
        mode.buttonY2 = 67
        mode.finalX1 = 1000
        mode.finalX2 = 1096
        mode.buildUp = False
        mode.final3 = False
        mode.release = False
        mode.drawArrows = False
        mode.arrows = []
        mode.mP = []
        mode.mR = []
        mode.mD = [(-1, -1)]
        mode.doneX1 = 156
        mode.animateAllX1 = 40
        mode.doneX2 = 252
        mode.animateAllX2 = 136
        mode.buildUpAnimate = False
        mode.counterFormSX1 = 1175
        mode.counterFormSY1 = 295
        mode.counterFormSX2 = 1350
        mode.counterFormSY2 = 340
        mode.generateCounter = False
        mode.defenceX1 = 256
        mode.oppDefenceX1 = 976
        mode.defenceY1 = 83
        mode.oppDefenceY1 = mode.defenceY1
        mode.defenceX2 = 357
        mode.oppDefenceX2 = 1135
        mode.defenceY2 = 598
        mode.oppDefenceY2 = mode.defenceY2
        mode.midfield1X1 = mode.buildUpX2
        mode.oppMidfield1X1 = 920
        mode.midfield1Y1 = mode.defenceY1
        mode.oppMidfield1Y1 = mode.midfield1Y1
        mode.midfield1X2 = 469
        mode.oppMidfield1X2 = mode.oppDefenceX1
        mode.midfield1Y2 = mode.defenceY2
        mode.oppMidfield1Y2 = mode.midfield1Y2
        mode.midfield2X1 = mode.midfield1X2
        mode.oppAttackX2 = mode.oppMidfield2X1 = 767
        mode.midfield2Y1 = mode.midfield1Y1
        mode.oppMidfield2Y1 = mode.midfield2Y1
        mode.midfield2X2 = 555
        mode.oppMidfield2X2 = mode.oppMidfield1X1
        mode.midfield2Y2 = mode.midfield1Y2
        mode.oppMidfield2Y2 = mode.midfield2Y2
        mode.attackX1 = mode.midfield2X2
        mode.oppAttackX1 = 668
        mode.oppAttackY1 = mode.attackY1 = mode.midfield2Y1
        mode.attackX2 = 660
        mode.oppAttackY2 = mode.attackY2 = mode.midfield2Y2
        mode.counter3D = [[1152, 322, 1, False, (), ()], [1035, 205, 4, False, (), ()], [1035, 322, 5, False, (), ()], 
        [1035, 460, 6, False, (), ()]]
        mode.counter4D = [[1152, 322, 1, False, (), ()], [992,124, 2, False, (), ()], 
        [1043,258, 6, False, (), ()], [1046,390,5, False, (), ()], [999, 548, 3, False, (), ()]]
        mode.counter1Mid1 = [[952.5, 324, 4, False, (), ()]]
        mode.counter2Mid1 = [[895,241,4, False, (), ()], [895, 407, 8, False, (), ()]]
        mode.counter3Mid1 = [[900,241,4, False, (), ()], [900, 417, 8, False, (), ()], 
                        [900, 324, 10, False, (), ()]]

        mode.counter1Mid2 = [[801,322,10, False, (), ()]]
        mode.counter2Mid2 = [[782, 272, 7, False, (), ()], [782, 376, 11, False, (), ()]]
        mode.counter3Mid2 = [[792, 176, 7, False, (), ()], [792,322,10, False, (), ()], 
                            [792, 469, 11, False, (), ()]]
        mode.counter1Attack = [[687,322, 9, False, (), ()]]
        mode.counter2Attack = [[676, 241, 9, False, (), ()], [676, 406, 10, False, (), ()]]
        mode.counter3Attack = [[687,176,7, False, (), ()], [687, 322, 9, False, (), ()], 
                                [687,469,11, False, (), ()]]
        mode.finalAnimate = False
        mode.transitToF3 = False
        mode.ballCx = 204.5
        mode.ballCy = 322
        mode.moveBall = False
        mode.bI = 0
        mode.AIPlayers = []
        mode.ballBuildUpMoves = mode.playerBuildUpMoves = []
        mode.ballFinalMoves = mode.playerFinalMoves = []
        mode.findForm = True
        mode.prev = None
        mode.actualAIMovement = False
        mode.bAI = 0
        mode.rstFinale = False
        mode.doneBuildUp = []
        mode.playerMovement = False
        mode.ballMoves = []
        mode.animateAll = False
        mode.animateAllButton = False
        mode.buildUpWithBall = False
        mode.finalWithBall = False
        mode.noCounter = False

    def keyPressed(mode, event):
        if event.key == 'r' or event.key == 'b':
            mode.reset()
        elif event.key == 'f':
            mode.resetFinal()

    def reset(mode):
        mode.mP = []
        mode.mD = [(-1, -1)]
        mode.mR = []
        mode.release = False
        mode.drawArrows = False
        mode.players = [[182, 322, 1, False, (), (), False], [355, 548, 2, False, (), (), False], 
        [296, 390, 6, False, (), (), False], [293,258,5, False, (), (), False],[331, 124, 3, False, (), (), False], 
        [395, 407, 4, False, (), (), False], [395, 241, 8, False, (), (), False], [498, 176, 11, False, (), (), False],
        [498,322,10, False, (), (), False], [498, 469, 7, False, (), (), False],[603,322, 9, False, (), (), False]]
        if mode.buildUpWithBall:
            mode.ballCx = 204.5
            mode.ballCy = 322
    
    def resetFinal(mode):
        a = 0
        mode.mP = []
        mode.mD = [(-1, -1)]
        mode.mR = []
        mode.buildUpAnimate = False
        mode.release = False
        mode.drawArrows = False
        mode.fTarget = [[352, 322, 1, False, (), ()], [660, 552, 2, False, (), ()], 
        [543, 397, 6, False, (), ()], [532, 219 ,5, False, (), ()],[660, 128, 3, False, (), ()], 
        [650, 404, 4, False, (), ()], [651, 278, 8, False, (), ()], [825, 185, 11, False, (), ()],
        [823, 315, 10, False, (), ()], [831, 449, 7, False, (), ()],[952, 313, 9, False, (), ()]]
        for i in range(len(mode.fTarget)):
            mode.mPlayer(mode.players[i], mode.fTarget[i])
            if mode.reachedDestinationPlayerMovement(mode.players[i], mode.fTarget[i]):
                mode.doneBuildUp.append(mode.players[i][6])
        if len(mode.doneBuildUp) >= 86 and False not in mode.doneBuildUp:
            if mode.finalWithBall:
                mode.ballCx = 367
                mode.ballCy = 322
            mode.rstFinale = False
        
    def findFormation(mode):
        if mode.findForm:
            defenders = 0
            midfielder1 = 0
            midfielder2 = 0
            attackers = 0
            for player in mode.players:
                if (player[0] >= mode.defenceX1 and player[0] <= mode.defenceX2) and (
                    player[1] >= mode.defenceY1 and player[1] <= mode.defenceY2):
                        defenders += 1
                elif (player[0] >= mode.midfield1X1 and player[0] <= mode.midfield1X2) and (
                    player[1] >= mode.midfield1Y1 and player[1] <= mode.midfield1Y2):
                        midfielder1 += 1
                elif (player[0] >= mode.midfield2X1 and player[0] <= mode.midfield2X2) and (
                    player[1] >= mode.midfield2Y1 and player[1] <= mode.midfield2Y2):
                        midfielder2 += 1
                elif (player[0] >= mode.attackX1 and player[0] <= mode.attackX2) and (
                    player[1] >= mode.attackY1 and player[1] <= mode.attackY2):
                        attackers += 1
            s = f'{defenders}{midfielder1}{midfielder2}{attackers}'
            if '0' in s:
                for i in range(len(s)):
                    if s[i] == '0':
                        t = s.replace(s[i], "")
                mode.prev = t
                return t
            else:
                mode.prev = s
                return s

    def getAIForm(mode):
        defenders = 0
        midfielder1 = 0
        midfielder2 = 0
        attackers = 0
        for player in mode.players:
            if (player[0] >= mode.oppDefenceX1 and player[0] <= mode.oppDefenceX2) and (
                player[1] >= mode.oppDefenceY1 and player[1] <= mode.oppDefenceY2):
                    defenders += 1
            elif (player[0] >= mode.oppMidfield1X1 and player[0] <= mode.oppMidfield1X2) and (
                player[1] >= mode.oppMidfield1Y1 and player[1] <= mode.oppMidfield1Y2):
                    midfielder1 += 1
            elif (player[0] >= mode.oppMidfield2X1 and player[0] <= mode.oppMidfield2X2) and (
                player[1] >= mode.oppMidfield2Y1 and player[1] <= mode.oppMidfield2Y2):
                    midfielder2 += 1
            elif (player[0] >= mode.oppAttackX1 and player[0] <= mode.oppAttackX2) and (
                player[1] >= mode.oppAttackY1 and player[1] <= mode.oppAttackY2):
                    attackers += 1
        s = f'{defenders}{midfielder1}{midfielder2}{attackers}'
        if '0' in s:
            for i in range(len(s)):
                if s[i] == '0':
                    t = s.replace(s[i], "")
            return t
        else:
            return s
        
    def distance(mode, x1, y1, x2, y2):
        return ((x1-x2)**2 + (y1-y2)**2)**0.5 

    def mousePressed(mode, event):
        if (event.x >= 10 and event.x <= 60) and (event.y >= mode.height-50 and
            event.y <= mode.height):
                mode.app.setActiveMode(mode.app.createMode)
                mode.reset()
                mode.buildUp = False
                mode.final3 = False
                mode.buildUpWithBall = False
                mode.finalWithBall = False
                mode.generateCounter = False

        elif (event.x >= mode.buildUpX1 and event.x <= mode.buildUpX2) and (
            event.y >= mode.buttonY1 and event.y <= mode.buttonY2):
                mode.buildUp = True
                inp = mode.getUserInput('Animate With ball(B) or Without ball(NB)\n Type B or NB below')
                if inp != None:
                    inp = inp.lower()
                    if inp == 'b':
                        mode.buildUpWithBall = True
                    else: mode.buildUpWithBall = False
                mode.reset()
                mode.drawArrows = True
        
        elif (event.x >= mode.counterFormSX1 and event.x <= mode.counterFormSX2) and (
            event.y >= mode.counterFormSY1 and event.y <= mode.counterFormSY2):
                mode.generateCounter = True

        elif (event.x >= mode.finalX1 and event.x <= mode.finalX2) and (
            event.y >= mode.buttonY1 and event.y <= mode.buttonY2):
                mode.final3 = True
                mode.rstFinale = True
                inp = mode.getUserInput('Animate With ball(B) or Without ball(NB)\n Type B or NB below')
                if inp != None:
                    inp = inp.lower()
                    if inp == 'b':
                        mode.buildUpWithBall = False
                        mode.finalWithBall = True
                    else: mode.finalWithBall = False
                mode.animateAllButton = True
                mode.resetFinal()
                mode.drawArrows = True
                mode.transitToF3 = True
                mode.buildUpAnimate = False

        elif (event.x >= mode.doneX1 and event.x <= mode.doneX2) and (
            event.y >= mode.buttonY1 and event.y <= mode.buttonY2) and (
                mode.buildUp):
                    mode.buildUpAnimate = True
                    mode.drawArrows = False
                    mode.buildUp = False
                    mode.arrowInPlayer(mode.players)
                    # mode.final3 = False
        
        elif (event.x >= mode.doneX1 and event.x <= mode.doneX2) and (
            event.y >= mode.buttonY1 and event.y <= mode.buttonY2) and (
                mode.final3):
                    mode.finalAnimate = True
                    mode.drawArrows = False
                    mode.final3 = False
                    mode.arrowInPlayer(mode.players)
        
        elif mode.buildUp and mode.pointIsInPlayer(event.x, event.y) and (
            event.x >= 165 and event.x <= 1165) and (
                event.y >= 80 and event.y <= 600):
                    mode.mP.append((event.x, event.y))
                    mode.release = False

        elif (mode.final3 and mode.pointIsInPlayer(event.x, event.y)) and (
              event.x >= 165 and event.x <= 1165) and (event.y >= 80 and event.y <= 600):
                    mode.mP.append((event.x, event.y))
                    mode.release = False

        else:
            for player in mode.players:
                pCx = player[0]
                pCy = player[1]
                pNum = player[2]
                r = 15
                dist = mode.distance(event.x, event.y, pCx, pCy)
                if dist <= r+25:
                    return player  

    def mouseReleased(mode, event):
        if mode.buildUp and len(mode.mP) != 0:
            mode.mR.append((event.x, event.y))
            mode.release = True

        elif mode.final3 and len(mode.mP) != 0:
            mode.mR.append((event.x, event.y))
            mode.release = True

    def pointIsInPlayer(mode,x1, y1):
        for player in mode.players:
            if mode.distance(x1, y1, player[0], player[1]) <= 15:
                return True
        return False

    def arrowInPlayer(mode, players):
        if mode.buildUpAnimate:
            for (x1, y1) in mode.mP:
                for player in players:
                    if mode.distance(x1, y1, player[0], player[1]) <= 15:
                        player[3] = True
                        player[5] = mode.mR[mode.mP.index((x1, y1))]
                        mode.playerBuildUpMoves.append((player[5], player[2]))
                        mode.ballMoves.append((player[5], player[2]))

        elif mode.finalAnimate:
            for (x1, y1) in mode.mP:
                for player in players:
                    if mode.distance(x1, y1, player[0], player[1]) <= 15:
                        player[3] = True
                        player[5] = mode.mR[mode.mP.index((x1, y1))]
                        mode.playerFinalMoves.append((player[5], player[2]))
                        mode.ballMoves.append((player[5], player[2]))

    def reachedDestinationPlayer(mode, player):
        if player[5] != () and abs(player[0] - player[5][0]) <= 9.5 and abs(player[1] - player[5][1]) <= 9.5: 
            return True
        else: return False

    def reachedDestinationPlayerMovement(mode, player, destination):
        if destination != None and abs(player[0] - destination[0]) <= 15 and abs(player[1] - destination[1]) <= 15:
            return True
        else: return False

    def reachedDestinationBall(mode, move):
        if move != () and abs(mode.ballCx - move[0][0]) <= 7.5 and abs(mode.ballCy - move[0][1]) <= 7.5:
            return True
        else: return False

    def reachedDestinationBallAI(mode, move):
        if move != () and abs(mode.ballCx - move[0]) <= 7.5 and abs(mode.ballCy - move[1]) <= 7.5:
            return True
        else: return False
    
    # def moveAll(mode):
    #     for i in range(len(mode.playerBuildUpMoves)):
    #         for player in mode.players:
    #             if player[2] == mode.playerBuildUpMoves[i][1]:
    #                 mode.mPlayer(player, mode.playerBuildUpMoves[i][0])
    #                 try:
    #                     if player[2] == mode.ballMoves[mode.bI][1]:
    #                         mode.moveBall = True
    #                         mode.mBall(mode.ballMoves[mode.bI]) 
    #                 except:
    #                 mode.moveBall = False 
    #                 mode.mBall(mode.ballBuildUpMoves[i])

    # def reachedDestination(mode, player):
    #     if not mode.playerAIMovement or (mode.playerAIMovement and type(player) == list):
    #         try:
    #             if player[5] != () and abs(player[0] - player[5][0]) <= 9.5 and abs(player[1] - player[5][1]) <= 9.5: 
    #                 return True
    #             else: return False
    #         except:
    #             move = player
    #             if move != () and abs(mode.ballCx - move[0][0]) <= 7.5 and abs(mode.ballCy - move[0][1]) <= 7.5:
    #                 return True
    #             else: return False

    #     elif mode.playerAIMovement and type(player) == tuple:
    #         move = player
    #         if move != () and abs(mode.ballCx - move[0]) <= 15 and abs(mode.ballCy - move[1]) <= 15:
    #             return True
    #         else: return False

    # def reachedDestination2(mode, player, destination):
    #     if abs(player[0] - destination[0]) <= 15 and abs(player[1] - destination[1]) <= 15:
    #         return True
    #     else: return False

    def mPlayer(mode, player, destination):
        if player[3]:
            if player[5][0] >= player[0] and player[5][1] >= player[1]:
                a = math.asin((player[5][1] - player[1]) / mode.distance(
                    player[0], player[1], player[5][0], player[5][1]))
                player[0] += abs(9.5*math.cos(a))
                player[1] += abs(9.5*math.sin(a))

            elif player[5][0] >= player[0] and player[5][1] <= player[1]:
                a = math.asin((player[1] - player[5][1]) / mode.distance(
                    player[0], player[1], player[5][0], player[5][1]))
                player[0] += abs(9.5*math.cos(a))
                player[1] -= abs(9.5*math.sin(a))

            elif player[0] >= player[5][0] and player[5][1] <= player[1]:
                a = math.asin((player[1] - player[5][1]) / mode.distance(
                    player[0], player[1], player[5][0], player[5][1]))
                player[0] -= abs(9.5*math.cos(a))
                player[1] -= abs(9.5*math.sin(a))

            elif player[0] >= player[5][0] and player[5][1] >= player[1]:
                a = math.asin((player[1] - player[5][1]) / mode.distance(
                    player[0], player[1], player[5][0], player[5][1]))
                player[0] -= abs(9.5*math.cos(a))
                player[1] += abs(9.5*math.sin(a))

            if mode.reachedDestinationPlayer(player):
                player[3] = False

        elif mode.animateAll:
            if not player[3] and destination != None:
                if destination[0] >= player[0] and destination[1] >= player[1]:
                        a = math.asin((destination[1] - player[1]) / mode.distance(
                            player[0], player[1], destination[0], destination[1]))
                        player[0] += abs(9.5*math.cos(a))
                        player[1] += abs(9.5*math.sin(a))

                elif destination[0] >= player[0] and destination[1] <= player[1]:
                    a = math.asin((player[1] - destination[1]) / mode.distance(
                        player[0], player[1], destination[0], destination[1]))
                    player[0] += abs(9.5*math.cos(a))
                    player[1] -= abs(9.5*math.sin(a))

                elif player[0] >= destination[0] and destination[1] <= player[1]:
                    a = math.asin((player[1] - destination[1]) / mode.distance(
                        player[0], player[1], destination[0], destination[1]))
                    player[0] -= abs(9.5*math.cos(a))
                    player[1] -= abs(9.5*math.sin(a))

                elif player[0] >= destination[0] and destination[1] >= player[1]:
                    a = math.asin((player[1] - destination[1]) / mode.distance(
                        player[0], player[1], destination[0], destination[1]))
                    player[0] -= abs(9.5*math.cos(a))
                    player[1] += abs(9.5*math.sin(a))

                if mode.reachedDestinationPlayerMovement(player, destination):
                    player[3] = True


        elif mode.rstFinale:
            if not player[6] and destination != None:
                if destination[0] >= player[0] and destination[1] >= player[1]:
                    a = math.asin((destination[1] - player[1]) / mode.distance(
                        player[0], player[1], destination[0], destination[1]))
                    player[0] += abs(9.5*math.cos(a))
                    player[1] += abs(9.5*math.sin(a))

                elif destination[0] >= player[0] and destination[1] <= player[1]:
                    a = math.asin((player[1] - destination[1]) / mode.distance(
                        player[0], player[1], destination[0], destination[1]))
                    player[0] += abs(9.5*math.cos(a))
                    player[1] -= abs(9.5*math.sin(a))

                elif player[0] >= destination[0] and destination[1] <= player[1]:
                    a = math.asin((player[1] - destination[1]) / mode.distance(
                        player[0], player[1], destination[0], destination[1]))
                    player[0] -= abs(9.5*math.cos(a))
                    player[1] -= abs(9.5*math.sin(a))

                elif player[0] >= destination[0] and destination[1] >= player[1]:
                    a = math.asin((player[1] - destination[1]) / mode.distance(
                        player[0], player[1], destination[0], destination[1]))
                    player[0] -= abs(9.5*math.cos(a))
                    player[1] += abs(9.5*math.sin(a))

        if mode.rstFinale and mode.reachedDestinationPlayerMovement(player, destination):
            player[6] = True

    def mBall(mode, move):
        if mode.moveBall:
            if mode.ballCx >= move[0][0] and mode.ballCy >= move[0][1]:
                    a = math.asin((mode.ballCy - move[0][1]) / mode.distance(
                        move[0][0], move[0][1], mode.ballCx, mode.ballCy))
                    mode.ballCx -= abs(13.5*math.cos(a))
                    mode.ballCy -= abs(13.5*math.sin(a))

            elif mode.ballCx >= move[0][0] and mode.ballCy <= move[0][1]:
                    a = math.asin((mode.ballCy - move[0][1]) / mode.distance(
                        move[0][0], move[0][1], mode.ballCx, mode.ballCy))
                    mode.ballCx -= abs(13.5*math.cos(a))
                    mode.ballCy += abs(13.5*math.sin(a)) 

            elif mode.ballCx <= move[0][0] and mode.ballCy <= move[0][1]:
                    a = math.asin((mode.ballCy - move[0][1]) / mode.distance(
                        move[0][0], move[0][1], mode.ballCx, mode.ballCy))
                    mode.ballCx += abs(13.5*math.cos(a))
                    mode.ballCy += abs(13.5*math.sin(a))

            elif mode.ballCx <= move[0][0] and mode.ballCy >= move[0][1]:
                    a = math.asin((mode.ballCy - move[0][1]) / mode.distance(
                        move[0][0], move[0][1], mode.ballCx, mode.ballCy))
                    mode.ballCx += abs(13.5*math.cos(a))
                    mode.ballCy -= abs(13.5*math.sin(a))

            if mode.reachedDestinationBall(move):
                mode.bI += 1
                mode.moveBall = False

        elif mode.animateAll:
            if mode.ballCx >= move[0][0] and mode.ballCy >= move[0][1]:
                    a = math.asin((mode.ballCy - move[0][1]) / mode.distance(
                        move[0][0], move[0][1], mode.ballCx, mode.ballCy))
                    mode.ballCx -= abs(13.5*math.cos(a))
                    mode.ballCy -= abs(13.5*math.sin(a))

            elif mode.ballCx >= move[0][0] and mode.ballCy <= move[0][1]:
                    a = math.asin((mode.ballCy - move[0][1]) / mode.distance(
                        move[0][0], move[0][1], mode.ballCx, mode.ballCy))
                    mode.ballCx -= abs(13.5*math.cos(a))
                    mode.ballCy += abs(13.5*math.sin(a)) 

            elif mode.ballCx <= move[0][0] and mode.ballCy <= move[0][1]:
                    a = math.asin((mode.ballCy - move[0][1]) / mode.distance(
                        move[0][0], move[0][1], mode.ballCx, mode.ballCy))
                    mode.ballCx += abs(13.5*math.cos(a))
                    mode.ballCy += abs(13.5*math.sin(a))

            elif mode.ballCx <= move[0][0] and mode.ballCy >= move[0][1]:
                    a = math.asin((mode.ballCy - move[0][1]) / mode.distance(
                        move[0][0], move[0][1], mode.ballCx, mode.ballCy))
                    mode.ballCx += abs(13.5*math.cos(a))
                    mode.ballCy -= abs(13.5*math.sin(a))

            if mode.reachedDestinationBall(move):
                mode.bI += 1
                mode.moveBall = False

    def timerFired(mode):
        if mode.buildUpAnimate:
            for player in mode.players:
                mode.mPlayer(player, None)
                try:
                    if player[2] == mode.ballMoves[mode.bI][1]:
                        mode.moveBall = True
                        mode.mBall(mode.ballMoves[mode.bI])
                except:
                    mode.moveBall = False                   

        elif mode.finalAnimate:
            for player in mode.players:
                mode.mPlayer(player, None)
                try:
                    if player[2] == mode.ballMoves[mode.bI][1]:
                        mode.moveBall = True
                        mode.mBall(mode.ballMoves[mode.bI]) 
                except:
                    mode.moveBall = False

        if mode.rstFinale:
            mode.resetFinal()

    def mouseDragged(mode, event):
        if (not mode.buildUp and not mode.final3):
            player = mode.mousePressed(event)
            if player != None:
                pCx = player[0]
                pCy = player[1]
                pNum = player[2]
                moveP = player[3]
                a = player[4]
                b = player[5]
                c = player[6]
                mode.players[mode.players.index([pCx, pCy, pNum, moveP, a, b, c ])] = [
                        event.x, event.y, pNum, moveP, a, b, c]

        elif (mode.buildUp and not mode.release):
                mode.mD[0] = (event.x, event.y)   

        elif (mode.final3 and not mode.release):
            mode.mD[0] = (event.x, event.y)   

    def drawBall(mode, canvas):
        r = 7.5
        canvas.create_oval(mode.ballCx-r, mode.ballCy-r, mode.ballCx+r,
            mode.ballCy+r, fill='white')

    def drawArrowsR(mode, canvas, pressed, released, dragged, a=0):
        for i in range(len(pressed)):
            try:
                canvas.create_line(pressed[i][0], pressed[i][1], released[i][0],
                released[i][1], arrow='last')
            except:
                pass

        if len(pressed) > 0 and not mode.release and (dragged[0][0] != dragged[0][1]):
            x1 = pressed[-1][0]
            y1 = pressed[-1][1]
            x2 = dragged[0][0]
            y2 = dragged[0][1]
            canvas.create_line(x1, y1, x2, y2, arrow='last')
                
    def drawBackground(mode, canvas):
        canvas.create_rectangle(0,0, mode.width, mode.height, fill='PaleGreen4')

    def drawPitch(mode, canvas):
        cx = mode.centerCircleCx
        cy = mode.centerCircleCy
        r = mode.centerCircleR
        dR = mode.kickOffDotR
        canvas.create_rectangle(165, 80, 1165, 600, fill='white',outline='black', width=3)
        canvas.create_line(665, 80, 665, 600, fill='black', width=3)
        canvas.create_oval(cx-r, cy-r, cx+r, cy+r, width=3)
        canvas.create_oval(cx-dR, cy-dR, cx+dR, cy+dR, fill='black')
        canvas.create_rectangle(mode.box18X1, mode.box18Y1, 
            mode.box18X2, mode.box18Y2, width=3)
        canvas.create_rectangle(mode.box6X1, mode.box6Y1, 
            mode.box6X2, mode.box6Y2, width=3)
        canvas.create_oval(mode.penaltyX-dR, mode.penaltyY-dR, mode.penaltyX+dR,
            mode.penaltyY+dR, fill='black')
        canvas.create_rectangle(mode.goalPostX1, mode.goalPostY1, 
            mode.goalPostX2, mode.goalPostY2, outline='black', width=3)

        for n in range(5, 20, 5):
            canvas.create_line(mode.goalPostX1+n, mode.goalPostY1, 
                mode.goalPostX1+n, mode.goalPostY2, width=1.5)
            canvas.create_line(mode.goalPostX1, mode.goalPostY1+n*4.5, 
                mode.goalPostX2, mode.goalPostY1+n*4.5, width=1.5)

        canvas.create_rectangle(mode.box18RX1, mode.box18Y1, mode.box18RX2,
        mode.box18Y2, width=3)
        canvas.create_oval(mode.penaltyRX-dR, mode.penaltyY-dR, 
        mode.penaltyRX+dR, mode.penaltyY+dR, fill='black')
        canvas.create_rectangle(mode.box6RX1, mode.box6Y1, 
            mode.box6RX2, mode.box6Y2, width=3)
        canvas.create_rectangle(mode.goalPostRX1, mode.goalPostY1, 
            mode.goalPostRX2, mode.goalPostY2, outline='black', width=3)

        for n in range(5, 20, 5):
            canvas.create_line(mode.goalPostRX1+n, mode.goalPostY1, 
                mode.goalPostRX1+n, mode.goalPostY2, width=1.5)
            canvas.create_line(mode.goalPostRX1, mode.goalPostY1+n*4.5, 
                mode.goalPostRX2, mode.goalPostY1+n*4.5, width=1.5)

        canvas.create_arc(mode.penaltyArcX1, mode.penaltyArcY1,
        mode.penaltyArcX2, mode.penaltyArcY2, start=90, extent=-180, 
        outline='black', width=3)
        canvas.create_arc(mode.rPenaltyArcX1, mode.rPenaltyArcY1,
        mode.rPenaltyArcX2, mode.rPenaltyArcY2, start=90, extent=180, 
        outline='black', width=3)
        canvas.create_rectangle(mode.defenceX1, mode.defenceY1, mode.defenceX2,
        mode.defenceY2, outline='white')
        canvas.create_rectangle(mode.midfield1X1, mode.midfield1Y1, 
        mode.midfield1X2, mode.midfield1Y2, outline='white')
        canvas.create_rectangle(mode.midfield2X1, mode.midfield2Y1, 
        mode.midfield2X2, mode.midfield2Y2, outline='white')
        canvas.create_rectangle(mode.attackX1, mode.attackY1, mode.attackX2,
        mode.attackY2, outline='white')

        canvas.create_rectangle(mode.oppDefenceX1, mode.oppDefenceY1, mode.oppDefenceX2,
        mode.oppDefenceY2, outline='white')
        canvas.create_rectangle(mode.oppMidfield1X1, mode.oppMidfield1Y1, 
        mode.oppMidfield1X2, mode.oppMidfield1Y2, outline='white')
        canvas.create_rectangle(mode.oppMidfield2X1, mode.oppMidfield2Y1, 
        mode.oppMidfield2X2, mode.oppMidfield2Y2, outline='white')
        canvas.create_rectangle(mode.oppAttackX1, mode.oppAttackY1, mode.oppAttackX2,
        mode.oppAttackY2, outline='white')

    def drawPlayers(mode, players, color1, colorOthers, canvas):
        for player in players:
            cx = player[0]
            cy = player[1]
            num = player[2]
            r = 15
            font = 'Arial 10 bold'
            if num == 1:
                fill = color1
            else:
                fill = colorOthers
            canvas.create_oval(cx-r, cy-r, cx+r, cy+r, fill=fill, activedash=2)
            if num < 10:
                canvas.create_text(cx, cy, text=f'{num}', fill='black', font=font,
                angle=-90)
            else:
                numS = str(num)
                canvas.create_text(cx, cy-5, text=numS[0], fill='black', 
                font=font, angle=-90)
                canvas.create_text(cx, cy+2.5, text=numS[1], fill='black',font=font,
                angle=-90)
    
    def drawTactButtons(mode, canvas):
        canvas.create_rectangle(mode.counterFormSX1, mode.counterFormSY1, 
            mode.counterFormSX2, mode.counterFormSY2, fill='purple')
        canvas.create_text(mode.counterFormSX1+86, mode.counterFormSY1+22.5,
        text='Generate Counter Formation!', fill='white', font='Arial 10 bold')
        if mode.buildUp or mode.final3:
            canvas.create_rectangle(mode.doneX1, mode.buttonY1, mode.doneX2,
            mode.buttonY2, fill='green')
            canvas.create_text(mode.doneX1+48,mode.buttonY1+22.5, text='DONE',
            fill='white')

        if not mode.final3:
            canvas.create_rectangle(mode.buildUpX1, mode.buttonY1, mode.buildUpX2,
            mode.buttonY2, fill='yellow')
            canvas.create_text(mode.buildUpX1+48, mode.buttonY1+22.5, text='BUILD UP PHASE')

        if not mode.buildUp:
            canvas.create_rectangle(mode.finalX1, mode.buttonY1, mode.finalX2,
            mode.buttonY2, fill='orange')
            canvas.create_text(mode.finalX1+48, mode.buttonY1+22.5, text='FINAL THIRD')

    def drawCounterFormation(mode, formation, canvas):
        if len(formation) == 3:
            # if (int(formation[0]) == 6 and int(formation[1]) == 3):
            #         mode.drawPlayers(mode.counter3D, 'yellow', 'blue', canvas)
            #         for player in mode.counter3D:
            #             if player not in mode.AIPlayers:
            #                 mode.AIPlayers.append(player)
            # else:
            #     mode.drawPlayers(mode.counter4D, 'yellow', 'blue', canvas)
            #     for player in mode.counter4D:
            #         if player not in mode.AIPlayers:
            #             mode.AIPlayers.append(player)

            if (int(formation[1]) == 5 or int(formation[1]) == 3) and int(formation[0] == 4):
                print(formation)
                mode.drawPlayers(mode.counter2Mid1, None, 'blue', canvas)
                mode.drawPlayers(mode.counter3Mid2, None, 'blue', canvas)
                mode.drawPlayers(mode.counter1Attack, None, 'blue', canvas)
                for player in mode.counter1Mid1:
                    if player not in mode.AIPlayers:
                        mode.AIPlayers.append(player)

            elif (int(formation[1]) == 5 or int(formation[0]) == 3) and (
                int(formation[0]) == 3 or int(formation[0]) == 5) or ():
                mode.drawPlayers(mode.counter3Mid1, None, 'blue', canvas)
                mode.drawPlayers(mode.counter3Attack, None, 'blue', canvas)
                for player in mode.counter3Mid1+mode.counter3Attack:
                    if player not in mode.AIPlayers:
                        mode.AIPlayers.append(player)

            elif int(formation[1]) == 3:
                mode.drawPlayers(mode.counter3Mid1, None, 'blue', canvas)
        
        elif len(formation) == 4:
            if int(formation[0]) == 6:
                    mode.drawPlayers(mode.counter3D, 'yellow', 'blue', canvas)
                    for player in mode.counter3D:
                        if player not in mode.AIPlayers:
                            mode.AIPlayers.append([player[0], player[1]])
            else:
                mode.drawPlayers(mode.counter4D, 'yellow', 'blue', canvas)
                for player in mode.counter4D:
                    if player not in mode.AIPlayers:
                        mode.AIPlayers.append(player)

            if int(formation[1]) + int(formation[2]) == 6:
                mode.drawPlayers(mode.counter3Mid1, None, 'blue', canvas)
                mode.drawPlayers(mode.counter3Attacke, None, 'blue', canvas)
                for player in mode.counter3Mid1+mode.counter3Attack:
                    if player not in mode.AIPlayers:
                        mode.AIPlayers.append(player)

            if int(formation[1]) + int(formation[2]) == 5:
                mode.drawPlayers(mode.counter1Mid1, None, 'blue', canvas)                
                mode.drawPlayers(mode.counter2Mid1, None, 'blue', canvas)
                mode.drawPlayers(mode.counter3Attack, None, 'blue', canvas)
                for player in mode.counter1Mid1+mode.counter2Mid1+mode.counter3Attack:
                    if player not in mode.AIPlayers:
                        mode.AIPlayers.append(player)
            
            elif int(formation[1]) + int(formation[2]) == 4:
                mode.drawPlayers(mode.counter2Mid1, None, 'blue', canvas)
                for player in mode.counter2Mid1:
                    if player not in mode.AIPlayers:
                        mode.AIPlayers.append(player)
                        
            if int(formation[0]) == 4:
                mode.drawPlayers(mode.counter3Attack, None, 'blue', canvas)
                for player in mode.counter3Attack:
                    if player not in mode.AIPlayers:
                        mode.AIPlayers.append(player)

    def redrawAll(mode, canvas):
        mode.drawBackground(canvas)
        canvas.create_line(10, mode.height-30, 60, mode.height-30, 
        fill='blue', arrow='first', width=35)
        canvas.create_text(35, (2*mode.height-60)/2, text='BACK', 
                                                    font='Arial 10 bold')
        mode.drawPitch(canvas)
        mode.drawPlayers(mode.players, 'green', 'red', canvas)
        if mode.buildUpWithBall:
            mode.drawBall(canvas)
        if mode.finalWithBall:
            mode.drawBall(canvas)
        mode.drawTactButtons(canvas)
        if mode.drawArrows:
            mode.drawArrowsR(canvas, mode.mP, mode.mR, mode.mD)
        if mode.generateCounter:
            formation = mode.findFormation()
            if formation != None:
                mode.drawCounterFormation(formation, canvas)
                if len(mode.AIPlayers) != 11:
                    mode.noCounter = True
                else:
                    f = mode.drawCounterFormation(formation, canvas)
                    mode.findForm = False
            else:
                mode.drawCounterFormation(mode.prev, canvas)
        if mode.noCounter:
            s = time.time()
            canvas.create_text(mode.width/2, mode.height/2, text='No Counter Formation Available',
            fill='gray', font='Arial 26 bold')
            mode.noCounter = False
        


class Four33Mode(Four231Mode):
    def appStarted(mode):
        Four231Mode.appStarted(mode)
        mode.players = [[182, 322, 1, False, (), (), False], [332, 549, 2, False, (), (), False], 
        [296, 390, 6, False, (), (), False], [293,258,5, False, (), (), False],
        [331, 124, 3, False, (), (), False], [374, 326, 4, False, (), (), False], 
        [420, 434, 8, False, (), (), False], [606,179, 11, False, (), (), False],
        [417, 219, 10, False, (), (), False], [611,452,7, False, (), (), False],
        [603,322, 9, False, (), (), False]]

    def reset(mode):
        mode.players = [[182, 322, 1, False, (), (), False], [332, 549, 2, False, (), (), False], 
        [296, 390, 6, False, (), (), False], [293,258,5, False, (), (), False],
        [331, 124, 3, False, (), (), False], [374, 326, 4, False, (), (), False], 
        [420, 434, 8, False, (), (), False], [606,179, 11, False, (), (), False],
        [417, 219, 10, False, (), (), False], [611,452,7, False, (), (), False],
        [603,322, 9, False, (), (), False]]
        mode.ballCx = 204.5
        mode.ballCy = 322

    def resetFinal(mode):
        Four231Mode.mode.resetFinal(mode)
        mode.fTarget = [[352, 322, 1, False, (), ()], [660, 552, 2, False, (), ()], 
        [543, 397, 6, False, (), ()], [532, 219 ,5, False, (), ()],[660, 128, 3, False, (), ()], 
        [670, 328, 4, False, (), ()], [740, 419, 8, False, (), ()], [952, 185, 11, False, (), ()],
        [740, 237, 10, False, (), ()], [952, 449, 7, False, (), ()],[952, 313, 9, False, (), ()]]


class CreateMineMode(Four231Mode):
    def appStarted(mode):
        Four231Mode.appStarted(mode)
        mode.players = [[186, 619, 1, False, (), (), False], [221, 619, 2, False, (), (), False], 
        [256, 619, 6, False, (), (), False], [289, 619 ,5, False, (), (), False],[324, 619 , 3, False, (), (), False], 
        [359, 619 , 4, False, (), (), False], [394, 619 , 8, False, (), (), False], [429, 619, 11, False, (), (), False],
        [464,619,10, False, (), (), False], [499, 619, 7, False, (), (), False],[534, 619, 9, False, (), (), False]]

    def reset(mode):
        mode.players = [[186, 619, 1, False, (), (), False], [221, 619, 2, False, (), (), False], 
        [256, 619, 6, False, (), (), False], [289, 619 ,5, False, (), (), False],[324, 619 , 3, False, (), (), False], 
        [359, 619 , 4, False, (), (), False], [394, 619 , 8, False, (), (), False], [429, 619, 11, False, (), (), False],
        [464,619,10, False, (), (), False], [499, 619, 7, False, (), (), False],[534, 619, 9, False, (), (), False]]

    def mousePressed(mode, event):
        if (event.x >= 10 and event.x <= 60) and (event.y >= mode.height-50 and
            event.y <= mode.height):
                mode.app.setActiveMode(mode.app.createMode)
                # mode.reset()
                mode.buildUp = False
                mode.final3 = False
                mode.buildUpWithBall = False
                mode.finalWithBall = False
                mode.generateCounter = False

        elif (event.x >= mode.buildUpX1 and event.x <= mode.buildUpX2) and (
            event.y >= mode.buttonY1 and event.y <= mode.buttonY2):
                mode.buildUp = True
                inp = mode.getUserInput('Animate With ball(B) or Without ball(NB)\n Type B or NB below')
                if inp != None:
                    inp = inp.lower()
                    if inp == 'b':
                        mode.buildUpWithBall = True
                    else: mode.buildUpWithBall = False
                # mode.reset()
                mode.drawArrows = True
        
        elif (event.x >= mode.counterFormSX1 and event.x <= mode.counterFormSX2) and (
            event.y >= mode.counterFormSY1 and event.y <= mode.counterFormSY2):
                mode.generateCounter = True

        elif (event.x >= mode.finalX1 and event.x <= mode.finalX2) and (
            event.y >= mode.buttonY1 and event.y <= mode.buttonY2):
                mode.final3 = True
                mode.rstFinale = True
                inp = mode.getUserInput('Animate With ball(B) or Without ball(NB)\n Type B or NB below')
                if inp != None:
                    inp = inp.lower()
                    if inp == 'b':
                        mode.finalWithBall = True
                        mode.buildUpWithBall = False
                    else: mode.finalWithBall = False
                mode.animateAllButton = True
                mode.resetFinal()
                mode.drawArrows = True
                mode.transitToF3 = True
                mode.buildUpAnimate = False

        elif (event.x >= mode.doneX1 and event.x <= mode.doneX2) and (
            event.y >= mode.buttonY1 and event.y <= mode.buttonY2) and (
                mode.buildUp):
                    mode.buildUpAnimate = True
                    mode.drawArrows = False
                    mode.buildUp = False
                    mode.arrowInPlayer(mode.players)
                    # mode.final3 = False
        
        elif (event.x >= mode.doneX1 and event.x <= mode.doneX2) and (
            event.y >= mode.buttonY1 and event.y <= mode.buttonY2) and (
                mode.final3):
                    mode.finalAnimate = True
                    mode.drawArrows = False
                    mode.final3 = False
                    mode.arrowInPlayer(mode.players)
        
        elif mode.buildUp and mode.pointIsInPlayer(event.x, event.y) and (
            event.x >= 165 and event.x <= 1165) and (
                event.y >= 80 and event.y <= 600):
                    mode.mP.append((event.x, event.y))
                    mode.release = False

        elif (mode.final3 and mode.pointIsInPlayer(event.x, event.y)) and (
              event.x >= 165 and event.x <= 1165) and (event.y >= 80 and event.y <= 600):
                    mode.mP.append((event.x, event.y))
                    mode.release = False

        else:
            for player in mode.players:
                pCx = player[0]
                pCy = player[1]
                pNum = player[2]
                r = 15
                dist = mode.distance(event.x, event.y, pCx, pCy)
                if dist <= r+25:
                    return player  

    def timerFired(mode):
        Four231Mode.timerFired(mode)
        total = 0
        l = str(mode.findFormation())
        for each in l:
            total += int(each)
        if total == 11:
            fle = open(f'{userName}.txt', 'a+')
            contents = fle.splitlines()
            if f'Formation Last Used:{int(l)}' not in contents:
                fle.write(f'Formation Last Used:{int(l)}')

class MyModalApp(ModalApp):
    def appStarted(app):
        app.splashScreenMode = SplashScreenMode()
        app.createMode = CreateMode()
        app.create4231 = Four231Mode()
        app.create433 = Four33Mode()
        app.CreateMine = CreateMineMode()
        app.setActiveMode(app.splashScreenMode)
app = MyModalApp(width=1366, height=705)
